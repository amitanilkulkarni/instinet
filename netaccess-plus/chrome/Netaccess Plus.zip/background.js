var Uname='', Pwd='', id=0;

function start() {

    // Use default value color = 'red' and likesColor = true.
    chrome.storage.sync.get({
        Uname: '',
        Pwd: ''
    }, function(items) {
        Uname = items.Uname;
        Pwd = items.Pwd;
        req1();
    });
}

function req1() {
    var login = new FormData();
    login.append('userLogin', Uname);
    login.append('userPassword', Pwd);


    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://netaccess.iitm.ac.in/account/login', true);
    xhr.onload = function () {
        // Is anyone home?

		if (this.responseText.search("failed") != -1) {
		    var options = {
		        body: "Correct the username and password you provided in options of this extension.",
		        icon: "notify/loginerror.png"
		    }
		    new Notification("Login failed.", options);
		}
		else if (this.responseText.search("approve") != -1) {
		    //console.log("Good to go!");
		    req2();
		}
		else if (this.responseText.search("approve") == -1) {
		    var options = {
		        body: "Disable any proxies you are using. If not, try renewing your IP address.",
		        icon: "notify/hproxy.png"
		    }
		    new Notification("Can't approve this IP.", options);
		}
    };
    xhr.onerror = function() {
	    var options = {
	        body: "Connection failed. Check your internet connection.",
	        icon: "notify/offline.png"
	    }
	    new Notification("Offline?", options);
    }
    xhr.send(login);
}

function req2() {

    var login = new FormData();
    login.append('duration', 2);
    login.append('approveBtn', '');


    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://netaccess.iitm.ac.in/account/approve', true);
    xhr.onload = function () {

		    var options = {
		        body: "Approved for one day.",
		        icon: "notify/success.png"
		    }
		    new Notification("Success!.", options);

	        //console.log(this.responseText);

            if (id==0) {
                //console.log('new');
	            badgeLoop();
        	    id = setInterval(function(){
	            	badgeLoop();
	            }, 600000);
            }
            else {
                clearInterval(id);
                //console.log('cleared');
	            badgeLoop();
        	    id = setInterval(function(){
	            	badgeLoop();
	            }, 600000);
            }
    };
    xhr.send(login);

}

function badgeLoop() {

    var dbegin, dend;

    var login = new FormData();
    login.append('userLogin', Uname);
    login.append('userPassword', Pwd);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://netaccess.iitm.ac.in/account/login', true);
	xhr.onload = function () {

	    if (this.responseText.search("Home") != -1) {

	    	if(this.responseText.search("<b>Total download:</b>      0 B<p>") != -1) {
    	        chrome.browserAction.setBadgeText({text:"✓"});
	    	}

	    	else {

			dbegin = this.responseText.search("<b>Total download:</b> ");
			dend = this.responseText.search("B<p>");

			if (this.responseText.substring(dbegin+23, dend).search("K") != -1) {
			    chrome.browserAction.setBadgeText({text: "0%"});
			}
			else if (this.responseText.substring(dbegin+23, dend).search("G") != -1) {
			    chrome.browserAction.setBadgeText({text:":("});
			}
			else {
			    chrome.browserAction.setBadgeText({text: this.responseText.substring(dbegin+23, dend-6) + "%"});
			}

		}

	    }

	}
    xhr.send(login);

}

chrome.browserAction.onClicked.addListener(start);

chrome.runtime.onInstalled.addListener(function (object) {
    chrome.runtime.openOptionsPage();
});
