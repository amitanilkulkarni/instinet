// Saves options to chrome.storage.sync.
function save_options() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    chrome.storage.sync.set({
        Uname: username,
        Pwd: password
    });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default value color = 'red' and likesColor = true.
  chrome.storage.sync.get({
    Uname: '',
    Pwd: ''
  }, function(items) {
    document.getElementById('username').value = items.Uname;
    document.getElementById('password').value = items.Pwd;
  });
}
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);
